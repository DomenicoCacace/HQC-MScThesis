#include "niederreiter_keygen.h"
#include "niederreiter_encrypt.h"
#include "niederreiter_decrypt.h"
#include "gf2x_arith_mod_xPplusOne.h"
#include "rng.h"
#include "sha3.h"
#include <string.h>
#include "dump.h"
#include "api.h"



int main() {

  unsigned char  *pk       = calloc(1, CRYPTO_PUBLICKEYBYTES),
                 *sk       = calloc(1, CRYPTO_SECRETKEYBYTES),
                 *ss       = calloc(1, CRYPTO_BYTES),
                 *decap_ss = calloc(1, CRYPTO_BYTES),
                 *publicsyndrome= calloc(1, CRYPTO_CIPHERTEXTBYTES);

  #ifdef TRNG
    __HAL_RCC_RNG_CLK_ENABLE();
    TRNG_init();
  #endif

  int rand = pick_TRNG_value();  

  initialize_pseudo_random_generator_seed(1,&rand);
  key_gen_niederreiter(pk,sk);

  //printf("iter %d\n",i);

  encrypt_niederreiter_indcca2(publicsyndrome,ss,pk);

  decrypt_niederreiter_indcca2(decap_ss,publicsyndrome,sk);

  int cmp = memcmp(ss, decap_ss, CRYPTO_BYTES);

  if(cmp==0)
    printf("decrypt OK\n");
  else
    printf("decrypt NO\n");

  free(pk);
  free(sk);
  free(ss);
  free(decap_ss);
  free(publicsyndrome);
}