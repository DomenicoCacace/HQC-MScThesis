#include <stdio.h>
#include <assert.h>
#include <stdlib.h>
#include <stdint.h>
#include <string.h>
#include <time.h>


void pn(unsigned long int n) {
  printf("val %lu \n", n);
}

void pn_32(uint32_t n) {
  printf("val %u \n", n);
}

void pt() {
  printf("OK \n");
}

void ps(char *s, unsigned long int n) {
  printf("%s %lu \n", s, n);
}

void nl() {
  printf("\n");
}

void vec_dump(uint64_t * v, int l) {
  int i;

  printf("[ 0x%lX", v[0]);

  for (i = 1; i < l; i++) {
    printf(", 0x%lX", v[i]);

  }

  printf("]");
}

void vec_dump_8(unsigned char * v, int l) {
  int i;

  printf("[ 0x%d", v[0]);

  for (i = 1; i < l; i++) {
    printf(", 0x%d", v[i]);

  }

  printf("]");
}


void sp_dump(uint64_t * v, int l) {
  int i;

  printf("[");

  printf("%lu", v[0]);
  for (i = 1; i < l; i++)
    printf(", %lu", v[i]);

  printf("]");
  nl();
}

void vec_dump_32(uint32_t * v, int l) {
  int i;

  printf("[ 0x%lX", v[0]);

  for (i = 1; i < l; i++) {
    printf(", 0x%llX", v[i]);

  }

  printf("]");
}

void dump_sp_poly(uint32_t * v, int len) {
  int i;

  printf("(x^%d", v[0]);
  for (i = 1; i < len; i++)
    printf(" + x^%d", v[i]);
  printf(")");
}

void dump_poly(uint64_t * v, int len) {
  int i, j;

  printf("(");

  for (i = 0; i < len; i++) {

    for (j = 0; j < DIGIT_SIZE_b; j++) {
      if (i == len - 1 && j == 0 && (v[i] >> j) & 1 != 0)
	    printf(" + %lu", (v[i] >> j) & 1);
        //nl();

      else if (i == len - 1 && j == 1 && (v[i] >> j) & 1 != 0)
	    printf(" + %lu*x", (v[i] >> j) & 1);
        //nl();

      else if ((v[i] >> j) & 1 != 0)
	    //pn(i);
	    printf(" + x^%lu", (len - 1 - i) * DIGIT_SIZE_b + j);

    }
  }

  printf(")");
  nl();
}

void print_bits(size_t const size, void const *const ptr) {
  unsigned char *b = (unsigned char *) ptr;
  unsigned char byte;
  int i, j;

  for (i = size - 1; i >= 0; i--) {
    for (j = 7; j >= 0; j--) {
      byte = (b[i] >> j) & 1;
      printf("%u", byte);
    }
  }
  puts("");
}

