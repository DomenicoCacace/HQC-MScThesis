#!/bin/sh

rm -r ./bin/*
make -j8
clear
./bin/main