#ifndef __CLOCK_H
#define __CLOCK_H

#include "stm32h7xx_hal.h"


static inline void reset_cnt()
{
	CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;
	ITM->LAR = 0xc5acce55;
	DWT->CYCCNT = 0;
	DWT->CTRL = 0;
}

static inline void start_cnt()
{
    DWT->CTRL |= 0x00000001 ; // enable the counter
}

static inline void stop_cnt()
{
     DWT->CTRL &= 0xFFFFFFFE ; // disable the counter

}

static inline unsigned int get_cycles()
{
    return DWT->CYCCNT ;
}

#endif
