################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Src/H_Q_matrices_generation.c \
../Src/aes256.c \
../Src/bf_decoding.c \
../Src/dfr_test.c \
../Src/djbsort.c \
../Src/gf2x_arith.c \
../Src/gf2x_arith_mod_xPplusOne.c \
../Src/inverse_exp.c \
../Src/kem.c \
../Src/main.c \
../Src/niederreiter_decrypt.c \
../Src/niederreiter_encrypt.c \
../Src/niederreiter_keygen.c \
../Src/rng.c \
../Src/sha3_fallback.c \
../Src/stm32h7xx_hal_msp.c \
../Src/stm32h7xx_it.c \
../Src/system_stm32h7xx.c 

OBJS += \
./Src/H_Q_matrices_generation.o \
./Src/aes256.o \
./Src/bf_decoding.o \
./Src/dfr_test.o \
./Src/djbsort.o \
./Src/gf2x_arith.o \
./Src/gf2x_arith_mod_xPplusOne.o \
./Src/inverse_exp.o \
./Src/kem.o \
./Src/main.o \
./Src/niederreiter_decrypt.o \
./Src/niederreiter_encrypt.o \
./Src/niederreiter_keygen.o \
./Src/rng.o \
./Src/sha3_fallback.o \
./Src/stm32h7xx_hal_msp.o \
./Src/stm32h7xx_it.o \
./Src/system_stm32h7xx.o 

C_DEPS += \
./Src/H_Q_matrices_generation.d \
./Src/aes256.d \
./Src/bf_decoding.d \
./Src/dfr_test.d \
./Src/djbsort.d \
./Src/gf2x_arith.d \
./Src/gf2x_arith_mod_xPplusOne.d \
./Src/inverse_exp.d \
./Src/kem.d \
./Src/main.d \
./Src/niederreiter_decrypt.d \
./Src/niederreiter_encrypt.d \
./Src/niederreiter_keygen.d \
./Src/rng.d \
./Src/sha3_fallback.d \
./Src/stm32h7xx_hal_msp.d \
./Src/stm32h7xx_it.d \
./Src/system_stm32h7xx.d 


# Each subdirectory must supply rules for building sources it contributes
Src/%.o: ../Src/%.c
	@echo 'Building file: $<'
	@echo 'Invoking: MCU GCC Compiler'
	@echo $(PWD)
	arm-none-eabi-gcc -mcpu=cortex-m7 -mthumb -mfloat-abi=hard -mfpu=fpv5-d16 '-D__weak=__attribute__((weak))' '-D__packed="__attribute__((__packed__))"' -DUSE_HAL_DRIVER -DSTM32H753xx -I"/home/prosdothewolf/thesis_prosdocimi/STM/Inc" -I"/home/prosdothewolf/thesis_prosdocimi/STM/Drivers/STM32H7xx_HAL_Driver/Inc" -I"/home/prosdothewolf/thesis_prosdocimi/STM/Drivers/STM32H7xx_HAL_Driver/Inc/Legacy" -I"/home/prosdothewolf/thesis_prosdocimi/STM/Drivers/CMSIS/Device/ST/STM32H7xx/Include" -I"/home/prosdothewolf/thesis_prosdocimi/STM/Drivers/CMSIS/Include"  -O3 -Wall -fmessage-length=0 -ffunction-sections -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


